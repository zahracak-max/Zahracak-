import { useEffect, useRef } from 'react';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

// Landing Page Sections
import Navigation from './sections/Navigation';
import HeroSection from './sections/HeroSection';
import CategoryWheel from './sections/CategoryWheel';
import DeliveryPromise from './sections/DeliveryPromise';
import FeaturedShops from './sections/FeaturedShops';
import RideFood from './sections/RideFood';
import TravelBooking from './sections/TravelBooking';
import ServicesRecharge from './sections/ServicesRecharge';
import JobsExport from './sections/JobsExport';
import HowItWorks from './sections/HowItWorks';
import BecomeSeller from './sections/BecomeSeller';
import Testimonials from './sections/Testimonials';
import Footer from './sections/Footer';

// Panel Layouts
import AdminLayout from './panels/admin/AdminLayout';
import VendorLayout from './panels/vendor/VendorLayout';
import DeliveryLayout from './panels/delivery/DeliveryLayout';

// Panel Dashboards
import AdminDashboard from './panels/admin/Dashboard';
import VendorDashboard from './panels/vendor/Dashboard';
import DeliveryDashboard from './panels/delivery/Dashboard';

// Auth
import Login from './panels/auth/Login';

gsap.registerPlugin(ScrollTrigger);

// Landing Page Component
const LandingPage = () => {
  const mainRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Wait for all sections to mount before setting up global snap
    const timer = setTimeout(() => {
      const pinned = ScrollTrigger.getAll()
        .filter(st => st.vars.pin)
        .sort((a, b) => a.start - b.start);
      
      const maxScroll = ScrollTrigger.maxScroll(window);
      
      if (!maxScroll || pinned.length === 0) return;

      const pinnedRanges = pinned.map(st => ({
        start: st.start / maxScroll,
        end: (st.end ?? st.start) / maxScroll,
        center: (st.start + ((st.end ?? st.start) - st.start) * 0.5) / maxScroll,
      }));

      ScrollTrigger.create({
        snap: {
          snapTo: (value: number) => {
            const inPinned = pinnedRanges.some(
              r => value >= r.start - 0.02 && value <= r.end + 0.02
            );
            if (!inPinned) return value;

            const target = pinnedRanges.reduce(
              (closest, r) =>
                Math.abs(r.center - value) < Math.abs(closest - value)
                  ? r.center
                  : closest,
              pinnedRanges[0]?.center ?? 0
            );
            return target;
          },
          duration: { min: 0.15, max: 0.35 },
          delay: 0,
          ease: 'power2.out',
        },
      });
    }, 500);

    return () => {
      clearTimeout(timer);
      ScrollTrigger.getAll().forEach(st => st.kill());
    };
  }, []);

  return (
    <div ref={mainRef} className="relative">
      {/* Grain Overlay */}
      <div className="grain-overlay" />
      
      {/* Navigation */}
      <Navigation />
      
      {/* Main Content */}
      <main className="relative">
        <HeroSection className="z-10" />
        <CategoryWheel className="z-20" />
        <DeliveryPromise className="z-30" />
        <FeaturedShops className="z-40" />
        <RideFood className="z-50" />
        <TravelBooking className="z-60" />
        <ServicesRecharge className="z-70" />
        <JobsExport className="z-80" />
        <HowItWorks className="z-90" />
        <BecomeSeller className="z-100" />
        <Testimonials className="z-110" />
        <Footer className="z-120" />
      </main>
    </div>
  );
};

// Router wrapper to handle scroll behavior
const RouterWrapper = () => {
  const location = useLocation();

  useEffect(() => {
    // Kill all ScrollTriggers when entering a panel
    if (location.pathname !== '/') {
      ScrollTrigger.getAll().forEach(st => st.kill());
    }
    // Scroll to top on route change
    window.scrollTo(0, 0);
  }, [location.pathname]);

  return (
    <Routes>
      {/* Landing Page */}
      <Route path="/" element={<LandingPage />} />
      
      {/* Auth */}
      <Route path="/login" element={<Login />} />
      <Route path="/admin/login" element={<Login defaultRole="admin" />} />
      <Route path="/vendor/login" element={<Login defaultRole="vendor" />} />
      <Route path="/delivery/login" element={<Login defaultRole="delivery" />} />
      
      {/* Admin Panel */}
      <Route path="/admin" element={<AdminLayout />}>
        <Route index element={<AdminDashboard />} />
        <Route path="users" element={<AdminDashboard />} />
        <Route path="vendors" element={<AdminDashboard />} />
        <Route path="orders" element={<AdminDashboard />} />
        <Route path="delivery" element={<AdminDashboard />} />
        <Route path="payments" element={<AdminDashboard />} />
        <Route path="analytics" element={<AdminDashboard />} />
        <Route path="support" element={<AdminDashboard />} />
        <Route path="reports" element={<AdminDashboard />} />
        <Route path="settings" element={<AdminDashboard />} />
      </Route>
      
      {/* Vendor Panel */}
      <Route path="/vendor" element={<VendorLayout />}>
        <Route index element={<VendorDashboard />} />
        <Route path="products" element={<VendorDashboard />} />
        <Route path="orders" element={<VendorDashboard />} />
        <Route path="analytics" element={<VendorDashboard />} />
        <Route path="earnings" element={<VendorDashboard />} />
        <Route path="messages" element={<VendorDashboard />} />
        <Route path="reviews" element={<VendorDashboard />} />
        <Route path="profile" element={<VendorDashboard />} />
        <Route path="settings" element={<VendorDashboard />} />
      </Route>
      
      {/* Delivery Panel */}
      <Route path="/delivery" element={<DeliveryLayout />}>
        <Route index element={<DeliveryDashboard />} />
        <Route path="orders" element={<DeliveryDashboard />} />
        <Route path="route" element={<DeliveryDashboard />} />
        <Route path="history" element={<DeliveryDashboard />} />
        <Route path="earnings" element={<DeliveryDashboard />} />
        <Route path="performance" element={<DeliveryDashboard />} />
        <Route path="support" element={<DeliveryDashboard />} />
        <Route path="settings" element={<DeliveryDashboard />} />
      </Route>
    </Routes>
  );
};

function App() {
  return (
    <BrowserRouter>
      <RouterWrapper />
    </BrowserRouter>
  );
}

export default App;
