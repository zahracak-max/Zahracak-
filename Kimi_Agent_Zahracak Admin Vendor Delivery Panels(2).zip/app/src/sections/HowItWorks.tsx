import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { MousePointer, CreditCard, Star } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface HowItWorksProps {
  className?: string;
}

const steps = [
  {
    number: '01',
    icon: MousePointer,
    title: 'Choose a service',
    description: 'Shop, ride, eat, travel, or apply—pick what you need.',
  },
  {
    number: '02',
    icon: CreditCard,
    title: 'Book in seconds',
    description: 'Compare, confirm, and pay securely.',
  },
  {
    number: '03',
    icon: Star,
    title: 'Track & enjoy',
    description: 'Get updates in real time and rate your experience.',
  },
];

const HowItWorks = ({ className = '' }: HowItWorksProps) => {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const cardsRef = useRef<(HTMLDivElement | null)[]>([]);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // Title animation
      gsap.fromTo(
        titleRef.current,
        { y: '8vh', opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: titleRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Cards animation
      cardsRef.current.forEach((card, i) => {
        if (!card) return;
        gsap.fromTo(
          card,
          { y: '10vh', rotate: -1, opacity: 0 },
          {
            y: 0,
            rotate: 0,
            opacity: 1,
            duration: 0.6,
            delay: i * 0.12,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: card,
              start: 'top 85%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      });
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className={`section-coral section-flowing py-24 ${className}`}
    >
      {/* Title */}
      <h2
        ref={titleRef}
        className="text-center text-white font-['League_Spartan'] font-bold mb-16 px-4"
        style={{ fontSize: 'clamp(28px, 3.5vw, 48px)', lineHeight: 1.1 }}
      >
        How Zahracak works
      </h2>

      {/* Steps Grid */}
      <div className="px-8 lg:px-[8vw]">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {steps.map((step, i) => (
            <div
              key={step.number}
              ref={(el) => { cardsRef.current[i] = el; }}
              className="bg-white rounded-[30px] p-7 shadow-lg hover:shadow-xl transition-shadow"
            >
              {/* Step Number */}
              <div className="w-12 h-12 bg-[#2F4858] rounded-full flex items-center justify-center mb-6">
                <span className="text-white font-bold text-sm">{step.number}</span>
              </div>

              {/* Icon */}
              <div className="w-14 h-14 bg-[#FF5A36]/10 rounded-2xl flex items-center justify-center mb-5">
                <step.icon className="w-7 h-7 text-[#FF5A36]" />
              </div>

              {/* Content */}
              <h3 className="text-[#2F4858] font-bold text-xl mb-3">
                {step.title}
              </h3>
              <p className="text-[#2F4858]/70 leading-relaxed">
                {step.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
