import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Smartphone, Receipt, FileText, Folder } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface ServicesRechargeProps {
  className?: string;
}

const servicePills = [
  { icon: Smartphone, label: 'Mobile Data' },
  { icon: Receipt, label: 'Bill Pay' },
  { icon: FileText, label: 'Registrations' },
  { icon: Folder, label: 'Documents' },
];

const ServicesRecharge = ({ className = '' }: ServicesRechargeProps) => {
  const sectionRef = useRef<HTMLElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const bodyRef = useRef<HTMLParagraphElement>(null);
  const pillsRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLButtonElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0%-30%)
      // Left image from left
      scrollTl.fromTo(
        imageRef.current,
        { x: '-60vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );

      // Right headline from right
      scrollTl.fromTo(
        headlineRef.current,
        { x: '50vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0.06
      );

      // Body
      scrollTl.fromTo(
        bodyRef.current,
        { y: '8vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.14
      );

      // Pills
      scrollTl.fromTo(
        pillsRef.current,
        { y: '8vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.2
      );

      // CTA
      scrollTl.fromTo(
        ctaRef.current,
        { y: '8vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.26
      );

      // SETTLE (30%-70%): Hold

      // EXIT (70%-100%)
      scrollTl.to(
        imageRef.current,
        { x: '-18vw', opacity: 0.35, ease: 'power2.in' },
        0.7
      );

      scrollTl.to(
        [headlineRef.current, bodyRef.current, pillsRef.current, ctaRef.current],
        { x: '18vw', opacity: 0.25, ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="services"
      className={`section-cream section-pinned flex items-center ${className}`}
    >
      <div className="w-full h-full flex flex-col lg:flex-row items-center justify-between px-8 lg:px-[7vw] py-20">
        {/* Left Image */}
        <div
          ref={imageRef}
          className="flex-1 max-w-lg mb-10 lg:mb-0 lg:mr-12"
        >
          <div className="card-rounded overflow-hidden shadow-2xl">
            <img
              src="/services_phone_ui.jpg"
              alt="Mobile recharge and government services"
              className="w-full h-auto object-cover"
              style={{ aspectRatio: '3/4' }}
            />
          </div>
        </div>

        {/* Right Content */}
        <div className="flex-1 max-w-xl">
          {/* Headline */}
          <h2
            ref={headlineRef}
            className="text-[#2F4858] font-['League_Spartan'] font-bold"
            style={{ fontSize: 'clamp(32px, 4.5vw, 56px)', lineHeight: 1.05 }}
          >
            Recharge &
            <br />
            government services.
          </h2>

          {/* Body */}
          <p
            ref={bodyRef}
            className="mt-6 text-[#2F4858]/80 leading-relaxed"
            style={{ fontSize: 'clamp(15px, 1.3vw, 18px)' }}
          >
            Top up data, pay bills, and complete registrations without leaving the app.
          </p>

          {/* Service Pills */}
          <div ref={pillsRef} className="mt-8 flex flex-wrap gap-3">
            {servicePills.map((pill) => (
              <div
                key={pill.label}
                className="flex items-center gap-2 bg-[#2F4858]/10 hover:bg-[#2F4858]/20 
                           border border-[#2F4858]/30 px-4 py-2 rounded-full cursor-pointer transition-colors"
              >
                <pill.icon className="w-4 h-4 text-[#2F4858]" />
                <span className="text-[#2F4858] text-sm font-medium">{pill.label}</span>
              </div>
            ))}
          </div>

          {/* CTA */}
          <button ref={ctaRef} className="btn-coral mt-10">
            Explore Services
          </button>
        </div>
      </div>
    </section>
  );
};

export default ServicesRecharge;
