import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface CategoryWheelProps {
  className?: string;
}

const categories = [
  { name: 'Electronics', image: '/category_electronics.jpg' },
  { name: 'Fashion', image: '/category_fashion.jpg' },
  { name: 'Home', image: '/category_home.jpg' },
  { name: 'Beauty', image: '/category_beauty.jpg' },
  { name: 'Sports', image: '/category_sports.jpg' },
  { name: 'Toys', image: '/category_toys.jpg' },
  { name: 'Groceries', image: '/category_groceries.jpg' },
  { name: 'Health', image: '/category_health.jpg' },
];

const CategoryWheel = ({ className = '' }: CategoryWheelProps) => {
  const sectionRef = useRef<HTMLElement>(null);
  const wheelRef = useRef<HTMLDivElement>(null);
  const centerRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLButtonElement>(null);
  const bubblesRef = useRef<(HTMLDivElement | null)[]>([]);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0%-30%)
      // Center headline circle
      scrollTl.fromTo(
        centerRef.current,
        { scale: 0.6, rotate: -10, opacity: 0 },
        { scale: 1, rotate: 0, opacity: 1, ease: 'none' },
        0
      );

      // Category bubbles
      bubblesRef.current.forEach((bubble, i) => {
        if (!bubble) return;
        const angle = (i / categories.length) * Math.PI * 2 - Math.PI / 2;
        const radius = 32; // vh units
        const x = Math.cos(angle) * radius;
        const y = Math.sin(angle) * radius;

        scrollTl.fromTo(
          bubble,
          { scale: 0.2, opacity: 0, x: 0, y: 0 },
          { scale: 1, opacity: 1, x: `${x}vh`, y: `${y}vh`, ease: 'none' },
          0.06 + i * 0.02
        );
      });

      // CTA button
      scrollTl.fromTo(
        ctaRef.current,
        { x: '10vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0.12
      );

      // SETTLE (30%-70%): Elements hold position

      // EXIT (70%-100%)
      scrollTl.to(
        wheelRef.current,
        { scale: 0.85, opacity: 0.35, ease: 'power2.in' },
        0.7
      );

      bubblesRef.current.forEach((bubble, i) => {
        if (!bubble) return;
        const angle = (i / categories.length) * Math.PI * 2 - Math.PI / 2;
        const radius = 38; // expanded radius
        const x = Math.cos(angle) * radius;
        const y = Math.sin(angle) * radius;

        scrollTl.to(
          bubble,
          { x: `${x}vh`, y: `${y}vh`, opacity: 0.3, ease: 'power2.in' },
          0.72
        );
      });

      scrollTl.to(
        ctaRef.current,
        { y: '-6vh', opacity: 0.2, ease: 'power2.in' },
        0.75
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="shop"
      className={`section-coral section-pinned flex items-center justify-center ${className}`}
    >
      {/* CTA Button */}
      <button
        ref={ctaRef}
        className="absolute right-[6vw] top-[10vh] btn-primary flex items-center gap-2 z-10"
      >
        Explore Marketplace
        <ArrowRight className="w-4 h-4" />
      </button>

      {/* Category Wheel */}
      <div
        ref={wheelRef}
        className="relative"
        style={{
          width: 'min(78vh, 80vw)',
          height: 'min(78vh, 80vw)',
        }}
      >
        {/* Dashed Ring */}
        <div
          className="absolute inset-0 rounded-full border-2 border-dashed border-[#2F4858]/20"
          style={{ transform: 'scale(0.85)' }}
        />

        {/* Center Headline */}
        <div
          ref={centerRef}
          className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 
                     w-[34vh] h-[34vh] max-w-[300px] max-h-[300px]
                     bg-white rounded-full flex items-center justify-center shadow-2xl z-10"
        >
          <h2
            className="text-center text-[#2F4858] font-['League_Spartan'] font-bold px-4"
            style={{ fontSize: 'clamp(20px, 3vh, 32px)', lineHeight: 1.1 }}
          >
            Shop every
            <br />
            category
          </h2>
        </div>

        {/* Category Bubbles */}
        {categories.map((category, i) => (
          <div
            key={category.name}
            ref={(el) => { bubblesRef.current[i] = el; }}
            className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"
          >
            <div className="flex flex-col items-center gap-2">
              <div
                className="w-[10vh] h-[10vh] max-w-[90px] max-h-[90px] min-w-[60px] min-h-[60px]
                           rounded-full overflow-hidden border-4 border-white shadow-lg
                           hover:scale-110 transition-transform cursor-pointer"
              >
                <img
                  src={category.image}
                  alt={category.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <span className="text-white text-sm font-medium whitespace-nowrap bg-[#2F4858]/50 px-3 py-1 rounded-full">
                {category.name}
              </span>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default CategoryWheel;
