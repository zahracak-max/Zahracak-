import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, Star } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface FeaturedShopsProps {
  className?: string;
}

const shops = [
  {
    name: 'Urban Electronics',
    offer: 'Up to 20% off',
    image: '/shop_electronics.jpg',
    rating: 4.8,
    reviews: 2340,
  },
  {
    name: 'Fresh Mart',
    offer: 'Free delivery',
    image: '/shop_grocery.jpg',
    rating: 4.9,
    reviews: 1890,
  },
  {
    name: 'Style Studio',
    offer: 'New arrivals',
    image: '/shop_fashion.jpg',
    rating: 4.7,
    reviews: 1560,
  },
  {
    name: 'Home Comfort',
    offer: 'Weekend deals',
    image: '/category_home.jpg',
    rating: 4.6,
    reviews: 980,
  },
];

const FeaturedShops = ({ className = '' }: FeaturedShopsProps) => {
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<(HTMLDivElement | null)[]>([]);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // Header animation
      gsap.fromTo(
        headerRef.current,
        { y: '8vh', opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: headerRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Cards animation
      cardsRef.current.forEach((card, i) => {
        if (!card) return;
        gsap.fromTo(
          card,
          { x: '10vw', rotate: 2, opacity: 0 },
          {
            x: 0,
            rotate: 0,
            opacity: 1,
            duration: 0.6,
            delay: i * 0.1,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: card,
              start: 'top 85%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      });
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className={`section-cream section-flowing py-24 ${className}`}
    >
      {/* Header */}
      <div
        ref={headerRef}
        className="px-8 lg:px-[8vw] flex items-end justify-between mb-10"
      >
        <h2
          className="text-[#2F4858] font-['League_Spartan'] font-bold"
          style={{ fontSize: 'clamp(28px, 3.5vw, 48px)', lineHeight: 1.1 }}
        >
          Featured shops
          <br />
          & deals
        </h2>
        <a
          href="#"
          className="hidden sm:flex items-center gap-2 text-[#2F4858] hover:text-[#FF5A36] transition-colors font-medium"
        >
          View all shops
          <ArrowRight className="w-4 h-4" />
        </a>
      </div>

      {/* Cards Row */}
      <div className="px-8 lg:px-[8vw]">
        <div className="flex gap-6 overflow-x-auto pb-6 snap-x snap-mandatory scrollbar-hide">
          {shops.map((shop, i) => (
            <div
              key={shop.name}
              ref={(el) => { cardsRef.current[i] = el; }}
              className="flex-shrink-0 w-[280px] sm:w-[320px] snap-start"
            >
              <div className="bg-white rounded-[32px] overflow-hidden shadow-lg hover:shadow-2xl transition-shadow cursor-pointer group">
                {/* Image */}
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={shop.image}
                    alt={shop.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-4 left-4 bg-[#FF5A36] text-white text-sm font-medium px-3 py-1 rounded-full">
                    {shop.offer}
                  </div>
                </div>

                {/* Content */}
                <div className="p-5">
                  <h3 className="text-[#2F4858] font-bold text-lg mb-2">
                    {shop.name}
                  </h3>
                  <div className="flex items-center gap-2">
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 fill-[#FF5A36] text-[#FF5A36]" />
                      <span className="text-[#2F4858] font-medium text-sm">
                        {shop.rating}
                      </span>
                    </div>
                    <span className="text-[#2F4858]/50 text-sm">
                      ({shop.reviews.toLocaleString()} reviews)
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Mobile View All Link */}
      <div className="sm:hidden px-8 mt-6">
        <a
          href="#"
          className="flex items-center gap-2 text-[#2F4858] hover:text-[#FF5A36] transition-colors font-medium"
        >
          View all shops
          <ArrowRight className="w-4 h-4" />
        </a>
      </div>
    </section>
  );
};

export default FeaturedShops;
