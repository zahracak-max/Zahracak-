import { useEffect, useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Search, MapPin, Apple, Play } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface HeroSectionProps {
  className?: string;
}

const HeroSection = ({ className = '' }: HeroSectionProps) => {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const subheadRef = useRef<HTMLParagraphElement>(null);
  const searchRef = useRef<HTMLDivElement>(null);
  const buttonsRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);

  // Auto-play entrance animation on load
  useEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: 'power3.out' } });

      tl.fromTo(
        headlineRef.current,
        { y: 24, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.5 },
        0.15
      )
        .fromTo(
          subheadRef.current,
          { y: 18, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.5 },
          0.35
        )
        .fromTo(
          searchRef.current,
          { scale: 0.96, y: 16, opacity: 0 },
          { scale: 1, y: 0, opacity: 1, duration: 0.55 },
          0.5
        )
        .fromTo(
          buttonsRef.current?.children || [],
          { y: 12, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.4, stagger: 0.08 },
          0.65
        )
        .fromTo(
          imageRef.current,
          { y: '10vh', scale: 0.98, opacity: 0 },
          { y: 0, scale: 1, opacity: 1, duration: 0.4 },
          0.7
        );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  // Scroll-driven exit animation
  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          onLeaveBack: () => {
            // Reset all elements when scrolling back to top
            gsap.set([headlineRef.current, subheadRef.current, searchRef.current], {
              opacity: 1,
              y: 0,
              x: 0,
            });
            gsap.set(buttonsRef.current, { opacity: 1, y: 0 });
            gsap.set(imageRef.current, { opacity: 1, y: 0, scale: 1 });
          },
        },
      });

      // ENTRANCE (0%-30%): Hold at fully visible (handled by load animation)
      // SETTLE (30%-70%): Static

      // EXIT (70%-100%)
      scrollTl
        .fromTo(
          headlineRef.current,
          { y: 0, opacity: 1 },
          { y: '-18vh', opacity: 0.25, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          subheadRef.current,
          { y: 0, opacity: 1 },
          { y: '-10vh', opacity: 0.2, ease: 'power2.in' },
          0.72
        )
        .fromTo(
          searchRef.current,
          { y: 0, opacity: 1 },
          { y: '-10vh', opacity: 0.2, ease: 'power2.in' },
          0.74
        )
        .fromTo(
          buttonsRef.current,
          { y: 0, opacity: 1 },
          { y: '-8vh', opacity: 0.2, ease: 'power2.in' },
          0.76
        )
        .fromTo(
          imageRef.current,
          { y: 0, scale: 1, opacity: 1 },
          { y: '18vh', scale: 0.98, opacity: 0.35, ease: 'power2.in' },
          0.75
        );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className={`section-coral section-pinned flex flex-col items-center justify-start pt-24 ${className}`}
    >
      {/* Headline */}
      <h1
        ref={headlineRef}
        className="text-center text-white font-['League_Spartan'] font-black mt-8"
        style={{
          fontSize: 'clamp(36px, 6vw, 80px)',
          width: '84vw',
          maxWidth: '900px',
          lineHeight: 1.0,
        }}
      >
        One app.
        <br />
        Everything you need.
      </h1>

      {/* Subheadline */}
      <p
        ref={subheadRef}
        className="text-center text-white/80 mt-6 px-4"
        style={{
          fontSize: 'clamp(16px, 1.5vw, 20px)',
          width: 'min(62vw, 760px)',
          maxWidth: '600px',
        }}
      >
        Shop local stores, book rides, order food, plan trips, and get services—fast.
      </p>

      {/* Search Bar */}
      <div
        ref={searchRef}
        className="mt-8 w-full max-w-3xl px-4"
      >
        <div className="bg-[#2F4858] rounded-2xl p-2 flex items-center gap-3 shadow-xl">
          <div className="flex items-center gap-2 px-4 text-white/70">
            <MapPin className="w-5 h-5" />
            <span className="text-sm hidden sm:inline">Deliver to</span>
          </div>
          <div className="flex-1 relative">
            <input
              type="text"
              placeholder="Search products, food, or services"
              className="w-full bg-white/10 text-white placeholder:text-white/50 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-[#FF5A36]"
            />
          </div>
          <button className="bg-[#FF5A36] hover:bg-[#e54d2b] text-white p-3 rounded-xl transition-colors">
            <Search className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* App Store Buttons */}
      <div ref={buttonsRef} className="mt-8 flex flex-wrap justify-center gap-4 px-4">
        <button className="flex items-center gap-3 bg-[#2F4858] hover:bg-[#3d5a6d] text-white px-6 py-3 rounded-2xl transition-all hover:scale-105">
          <Apple className="w-6 h-6" />
          <div className="text-left">
            <div className="text-xs text-white/70">Download on the</div>
            <div className="text-sm font-semibold">App Store</div>
          </div>
        </button>
        <button className="flex items-center gap-3 bg-[#2F4858] hover:bg-[#3d5a6d] text-white px-6 py-3 rounded-2xl transition-all hover:scale-105">
          <Play className="w-6 h-6" />
          <div className="text-left">
            <div className="text-xs text-white/70">Get it on</div>
            <div className="text-sm font-semibold">Google Play</div>
          </div>
        </button>
      </div>

      {/* Microcopy */}
      <p className="mt-4 text-white/60 text-sm">
        Free delivery on your first order.
      </p>

      {/* Hero Image */}
      <div
        ref={imageRef}
        className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-4xl px-4"
        style={{ bottom: '-2vh' }}
      >
        <img
          src="/hero_rider_phone.jpg"
          alt="Delivery rider with smartphone"
          className="w-full h-auto rounded-t-3xl shadow-2xl"
        />
      </div>
    </section>
  );
};

export default HeroSection;
