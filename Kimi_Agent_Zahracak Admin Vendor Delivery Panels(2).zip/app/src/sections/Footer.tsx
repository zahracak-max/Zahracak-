import { useRef, useLayoutEffect } from 'react';
import { Link } from 'react-router-dom';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Apple, Play, Instagram, Twitter, Facebook, Linkedin, User, Store, Bike } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface FooterProps {
  className?: string;
}

const footerLinks = {
  Shop: ['Marketplace', 'Deals', 'Sell on Zahracak'],
  Services: ['Ride', 'Food', 'Recharge', 'Gov Services'],
  Travel: ['Hotels', 'Flights', 'Buses'],
  Work: ['Jobs', 'Export/Import'],
};

const panelLinks = [
  { label: 'Admin Panel', icon: User, path: '/admin/login' },
  { label: 'Vendor Panel', icon: Store, path: '/vendor/login' },
  { label: 'Delivery Panel', icon: Bike, path: '/delivery/login' },
];

const Footer = ({ className = '' }: FooterProps) => {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const linksRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // Headline + buttons animation
      gsap.fromTo(
        headlineRef.current,
        { y: '6vh', opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: headlineRef.current,
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Links animation
      gsap.fromTo(
        linksRef.current?.children || [],
        { x: -20, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.6,
          stagger: 0.08,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: linksRef.current,
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <footer
      ref={sectionRef}
      className={`section-slate section-flowing py-20 ${className}`}
    >
      {/* CTA Section */}
      <div ref={headlineRef} className="px-8 lg:px-[8vw] mb-16">
        <h2
          className="text-white font-['League_Spartan'] font-bold mb-4"
          style={{ fontSize: 'clamp(32px, 4vw, 56px)', lineHeight: 1.05 }}
        >
          Download Zahracak today.
        </h2>
        <p className="text-white/70 text-lg mb-8">
          One account. One app. Everything you need.
        </p>

        {/* App Store Buttons */}
        <div className="flex flex-wrap gap-4">
          <button className="flex items-center gap-3 bg-transparent hover:bg-white/10 text-white px-6 py-3 rounded-2xl border-2 border-white/30 transition-all hover:scale-105">
            <Apple className="w-6 h-6" />
            <div className="text-left">
              <div className="text-xs text-white/70">Download on the</div>
              <div className="text-sm font-semibold">App Store</div>
            </div>
          </button>
          <button className="flex items-center gap-3 bg-transparent hover:bg-white/10 text-white px-6 py-3 rounded-2xl border-2 border-white/30 transition-all hover:scale-105">
            <Play className="w-6 h-6" />
            <div className="text-left">
              <div className="text-xs text-white/70">Get it on</div>
              <div className="text-sm font-semibold">Google Play</div>
            </div>
          </button>
        </div>
      </div>

      {/* Links Grid */}
      <div
        ref={linksRef}
        className="px-8 lg:px-[8vw] grid grid-cols-2 md:grid-cols-5 gap-8 mb-16"
      >
        {Object.entries(footerLinks).map(([category, links]) => (
          <div key={category}>
            <h3 className="text-white font-semibold mb-4">{category}</h3>
            <ul className="space-y-3">
              {links.map((link) => (
                <li key={link}>
                  <a
                    href="#"
                    className="text-white/60 hover:text-white transition-colors text-sm"
                  >
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        ))}
        
        {/* Panel Access */}
        <div>
          <h3 className="text-white font-semibold mb-4">Partner Access</h3>
          <ul className="space-y-3">
            {panelLinks.map((link) => (
              <li key={link.path}>
                <Link
                  to={link.path}
                  className="flex items-center gap-2 text-white/60 hover:text-white transition-colors text-sm"
                >
                  <link.icon className="w-4 h-4" />
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="px-8 lg:px-[8vw] pt-8 border-t border-white/10">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-[#FF5A36] rounded-xl flex items-center justify-center">
              <span className="text-white font-bold text-lg">Z</span>
            </div>
            <span className="text-white font-bold text-xl font-['League_Spartan']">
              Zahracak
            </span>
          </div>

          {/* Social Links */}
          <div className="flex items-center gap-4">
            <a href="#" className="text-white/60 hover:text-white transition-colors">
              <Instagram className="w-5 h-5" />
            </a>
            <a href="#" className="text-white/60 hover:text-white transition-colors">
              <Twitter className="w-5 h-5" />
            </a>
            <a href="#" className="text-white/60 hover:text-white transition-colors">
              <Facebook className="w-5 h-5" />
            </a>
            <a href="#" className="text-white/60 hover:text-white transition-colors">
              <Linkedin className="w-5 h-5" />
            </a>
          </div>

          {/* Copyright */}
          <p className="text-white/50 text-sm">
            © Zahracak. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
