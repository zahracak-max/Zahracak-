import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Bike, Car, Truck, Utensils, ShoppingBag } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface RideFoodProps {
  className?: string;
}

const rideOptions = [
  { icon: Bike, label: 'Bike' },
  { icon: Car, label: 'Car' },
  { icon: Truck, label: 'Auto' },
];

const foodOptions = [
  { icon: Utensils, label: 'Food' },
  { icon: ShoppingBag, label: 'Groceries' },
];

const RideFood = ({ className = '' }: RideFoodProps) => {
  const sectionRef = useRef<HTMLElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const bodyRef = useRef<HTMLParagraphElement>(null);
  const chipsRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0%-30%)
      // Left image from left
      scrollTl.fromTo(
        imageRef.current,
        { x: '-60vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );

      // Right headline from right
      scrollTl.fromTo(
        headlineRef.current,
        { x: '50vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0.06
      );

      // Body + chips
      scrollTl.fromTo(
        bodyRef.current,
        { y: '8vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.14
      );

      scrollTl.fromTo(
        chipsRef.current,
        { y: '8vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.2
      );

      scrollTl.fromTo(
        ctaRef.current,
        { y: '8vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.26
      );

      // SETTLE (30%-70%): Hold

      // EXIT (70%-100%)
      scrollTl.to(
        imageRef.current,
        { x: '-18vw', opacity: 0.35, ease: 'power2.in' },
        0.7
      );

      scrollTl.to(
        [headlineRef.current, bodyRef.current, chipsRef.current, ctaRef.current],
        { x: '18vw', opacity: 0.25, ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="ride"
      className={`section-coral section-pinned flex items-center ${className}`}
    >
      <div className="w-full h-full flex flex-col lg:flex-row items-center justify-between px-8 lg:px-[7vw] py-20">
        {/* Left Image */}
        <div
          ref={imageRef}
          className="flex-1 max-w-lg mb-10 lg:mb-0 lg:mr-12"
        >
          <div className="card-rounded overflow-hidden shadow-2xl">
            <img
              src="/ride_food_collage.jpg"
              alt="Ride and food services"
              className="w-full h-auto object-cover"
              style={{ aspectRatio: '3/4' }}
            />
          </div>
        </div>

        {/* Right Content */}
        <div className="flex-1 max-w-xl">
          {/* Headline */}
          <h2
            ref={headlineRef}
            className="text-white font-['League_Spartan'] font-bold"
            style={{ fontSize: 'clamp(32px, 4.5vw, 56px)', lineHeight: 1.05 }}
          >
            Ride & food,
            <br />
            on-demand.
          </h2>

          {/* Body */}
          <p
            ref={bodyRef}
            className="mt-6 text-white/80 leading-relaxed"
            style={{ fontSize: 'clamp(15px, 1.3vw, 18px)' }}
          >
            Get a bike or car in minutes. Order from local restaurants with live tracking and easy returns.
          </p>

          {/* Service Chips */}
          <div ref={chipsRef} className="mt-8">
            <div className="flex flex-wrap gap-4">
              {/* Ride Options */}
              <div className="flex gap-2">
                {rideOptions.map((option) => (
                  <div
                    key={option.label}
                    className="flex items-center gap-2 bg-white/10 hover:bg-white/20 
                               border border-white/30 px-4 py-2 rounded-full cursor-pointer transition-colors"
                  >
                    <option.icon className="w-4 h-4 text-white" />
                    <span className="text-white text-sm font-medium">{option.label}</span>
                  </div>
                ))}
              </div>

              {/* Food Options */}
              <div className="flex gap-2">
                {foodOptions.map((option) => (
                  <div
                    key={option.label}
                    className="flex items-center gap-2 bg-white/10 hover:bg-white/20 
                               border border-white/30 px-4 py-2 rounded-full cursor-pointer transition-colors"
                  >
                    <option.icon className="w-4 h-4 text-white" />
                    <span className="text-white text-sm font-medium">{option.label}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* CTAs */}
          <div ref={ctaRef} className="mt-10 flex flex-wrap gap-4">
            <button className="btn-primary">Book a Ride</button>
            <button className="btn-secondary">Order Food</button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default RideFood;
