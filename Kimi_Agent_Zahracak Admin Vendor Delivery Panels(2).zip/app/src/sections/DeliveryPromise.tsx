import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { MapPin, Shield, Headphones } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface DeliveryPromiseProps {
  className?: string;
}

const features = [
  { icon: MapPin, text: 'Real-time tracking' },
  { icon: Shield, text: 'Secure payments' },
  { icon: Headphones, text: '24/7 support' },
];

const DeliveryPromise = ({ className = '' }: DeliveryPromiseProps) => {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const bodyRef = useRef<HTMLParagraphElement>(null);
  const featuresRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLButtonElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0%-30%)
      // Headline from left
      scrollTl.fromTo(
        headlineRef.current,
        { x: '-50vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );

      // Body + features
      scrollTl.fromTo(
        bodyRef.current,
        { y: '10vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.1
      );

      scrollTl.fromTo(
        featuresRef.current,
        { y: '10vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.16
      );

      // Right image from right
      scrollTl.fromTo(
        imageRef.current,
        { x: '55vw', scale: 0.92, opacity: 0 },
        { x: 0, scale: 1, opacity: 1, ease: 'none' },
        0.06
      );

      // CTA
      scrollTl.fromTo(
        ctaRef.current,
        { y: '8vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.16
      );

      // SETTLE (30%-70%): Hold

      // EXIT (70%-100%)
      scrollTl.to(
        headlineRef.current,
        { x: '-18vw', opacity: 0.25, ease: 'power2.in' },
        0.7
      );

      scrollTl.to(
        [bodyRef.current, featuresRef.current],
        { x: '-18vw', opacity: 0.25, ease: 'power2.in' },
        0.72
      );

      scrollTl.to(
        imageRef.current,
        { x: '18vw', opacity: 0.35, ease: 'power2.in' },
        0.7
      );

      scrollTl.to(
        ctaRef.current,
        { opacity: 0.2, ease: 'power2.in' },
        0.8
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className={`section-coral section-pinned flex items-center ${className}`}
    >
      <div className="w-full h-full flex flex-col lg:flex-row items-center justify-between px-8 lg:px-[8vw] py-20">
        {/* Left Content */}
        <div className="flex-1 max-w-xl">
          {/* Headline */}
          <div ref={headlineRef}>
            <h2
              className="text-white font-['League_Spartan'] font-bold"
              style={{ fontSize: 'clamp(32px, 4.5vw, 56px)', lineHeight: 1.05 }}
            >
              From local stores
              <br />
              to your door.
            </h2>
          </div>

          {/* Body */}
          <p
            ref={bodyRef}
            className="mt-6 text-white/80 leading-relaxed"
            style={{ fontSize: 'clamp(15px, 1.3vw, 18px)' }}
          >
            We connect you to nearby sellers—groceries, fashion, electronics, and more—delivered in minutes.
          </p>

          {/* Features */}
          <div ref={featuresRef} className="mt-8 flex flex-col gap-4">
            {features.map((feature) => (
              <div key={feature.text} className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#2F4858] rounded-full flex items-center justify-center">
                  <feature.icon className="w-5 h-5 text-white" />
                </div>
                <span className="text-white font-medium">{feature.text}</span>
              </div>
            ))}
          </div>

          {/* CTA */}
          <button ref={ctaRef} className="btn-primary mt-10">
            Shop Near You
          </button>
        </div>

        {/* Right Image */}
        <div
          ref={imageRef}
          className="flex-1 max-w-lg mt-10 lg:mt-0 lg:ml-12"
        >
          <div className="card-rounded overflow-hidden shadow-2xl">
            <img
              src="/delivery_rider_packages.jpg"
              alt="Delivery rider handing over package"
              className="w-full h-auto object-cover"
              style={{ aspectRatio: '3/4' }}
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default DeliveryPromise;
