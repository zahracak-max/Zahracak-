import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface BecomeSellerProps {
  className?: string;
}

const BecomeSeller = ({ className = '' }: BecomeSellerProps) => {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const bodyRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLButtonElement>(null);
  const microcopyRef = useRef<HTMLParagraphElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0%-30%)
      // Headline from left
      scrollTl.fromTo(
        headlineRef.current,
        { x: '-50vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );

      // Body
      scrollTl.fromTo(
        bodyRef.current,
        { y: '10vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.1
      );

      // CTA pops in
      scrollTl.fromTo(
        ctaRef.current,
        { scale: 0.92, opacity: 0 },
        { scale: 1, opacity: 1, ease: 'none' },
        0.16
      );

      // Microcopy
      scrollTl.fromTo(
        microcopyRef.current,
        { y: '6vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.22
      );

      // Right image from right
      scrollTl.fromTo(
        imageRef.current,
        { x: '55vw', scale: 0.92, opacity: 0 },
        { x: 0, scale: 1, opacity: 1, ease: 'none' },
        0.06
      );

      // SETTLE (30%-70%): Hold

      // EXIT (70%-100%)
      scrollTl.to(
        [headlineRef.current, bodyRef.current, ctaRef.current, microcopyRef.current],
        { y: '8vh', opacity: 0.3, ease: 'power2.in' },
        0.7
      );

      scrollTl.to(
        imageRef.current,
        { y: '8vh', opacity: 0.35, ease: 'power2.in' },
        0.72
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className={`section-coral section-pinned flex items-center ${className}`}
    >
      <div className="w-full h-full flex flex-col lg:flex-row items-center justify-between px-8 lg:px-[8vw] py-20">
        {/* Left Content */}
        <div className="flex-1 max-w-xl">
          {/* Headline */}
          <div ref={headlineRef}>
            <h2
              className="text-white font-['League_Spartan'] font-bold"
              style={{ fontSize: 'clamp(32px, 4.5vw, 56px)', lineHeight: 1.05 }}
            >
              Become a seller.
            </h2>
          </div>

          {/* Body */}
          <p
            ref={bodyRef}
            className="mt-6 text-white/80 leading-relaxed"
            style={{ fontSize: 'clamp(15px, 1.3vw, 18px)' }}
          >
            Open your store, reach more customers, and grow with tools, analytics, and reliable payouts.
          </p>

          {/* CTA */}
          <button ref={ctaRef} className="btn-primary mt-10">
            Start Selling
          </button>

          {/* Microcopy */}
          <p ref={microcopyRef} className="mt-4 text-white/60 text-sm">
            Free setup · Dashboard included · Support 7 days a week
          </p>
        </div>

        {/* Right Image */}
        <div
          ref={imageRef}
          className="flex-1 max-w-lg mt-10 lg:mt-0 lg:ml-12"
        >
          <div className="card-rounded overflow-hidden shadow-2xl">
            <img
              src="/seller_packing.jpg"
              alt="Seller packing orders"
              className="w-full h-auto object-cover"
              style={{ aspectRatio: '3/4' }}
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default BecomeSeller;
