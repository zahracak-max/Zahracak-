import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Quote } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface TestimonialsProps {
  className?: string;
}

const testimonials = [
  {
    quote: "I run my shop on Zahracak—orders, payouts, and support are seamless.",
    author: 'Amina',
    role: 'Store Owner',
    avatar: 'A',
  },
  {
    quote: "I book rides and order dinner without switching apps. It just saves time.",
    author: 'Raj',
    role: 'Daily User',
    avatar: 'R',
  },
];

const Testimonials = ({ className = '' }: TestimonialsProps) => {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const cardsRef = useRef<(HTMLDivElement | null)[]>([]);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // Title animation
      gsap.fromTo(
        titleRef.current,
        { y: '8vh', opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: titleRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Cards animation
      cardsRef.current.forEach((card, i) => {
        if (!card) return;
        gsap.fromTo(
          card,
          { y: '8vh', opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.6,
            delay: i * 0.1,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: card,
              start: 'top 85%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      });
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className={`section-cream section-flowing py-24 ${className}`}
    >
      {/* Title */}
      <h2
        ref={titleRef}
        className="text-[#2F4858] font-['League_Spartan'] font-bold mb-12 px-8 lg:px-[8vw]"
        style={{ fontSize: 'clamp(28px, 3.5vw, 48px)', lineHeight: 1.1 }}
      >
        What people say
      </h2>

      {/* Testimonials Grid */}
      <div className="px-8 lg:px-[8vw]">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl">
          {testimonials.map((testimonial, i) => (
            <div
              key={testimonial.author}
              ref={(el) => { cardsRef.current[i] = el; }}
              className="bg-white rounded-[32px] p-8 shadow-lg"
            >
              {/* Quote Icon */}
              <div className="w-12 h-12 bg-[#FF5A36]/10 rounded-2xl flex items-center justify-center mb-6">
                <Quote className="w-6 h-6 text-[#FF5A36]" />
              </div>

              {/* Quote Text */}
              <p
                className="text-[#2F4858] text-lg leading-relaxed mb-8"
                style={{ fontSize: 'clamp(16px, 1.4vw, 20px)' }}
              >
                "{testimonial.quote}"
              </p>

              {/* Author */}
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-[#2F4858] rounded-full flex items-center justify-center">
                  <span className="text-white font-bold">{testimonial.avatar}</span>
                </div>
                <div>
                  <div className="text-[#2F4858] font-semibold">{testimonial.author}</div>
                  <div className="text-[#2F4858]/60 text-sm">{testimonial.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
