import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ShoppingCart, User, Menu, X, MapPin, Bike, Utensils, Plane, Briefcase, CreditCard } from 'lucide-react';

const Navigation = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'Shop', icon: MapPin, href: '#shop' },
    { label: 'Ride', icon: Bike, href: '#ride' },
    { label: 'Food', icon: Utensils, href: '#food' },
    { label: 'Travel', icon: Plane, href: '#travel' },
    { label: 'Services', icon: CreditCard, href: '#services' },
    { label: 'Jobs', icon: Briefcase, href: '#jobs' },
  ];

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-[1000] transition-all duration-500 ${
        isScrolled
          ? 'bg-[#2F4858]/95 backdrop-blur-md shadow-lg py-3'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="w-full px-6 lg:px-12 flex items-center justify-between">
        {/* Logo */}
        <a href="#" className="flex items-center gap-2">
          <div className="w-10 h-10 bg-[#FF5A36] rounded-xl flex items-center justify-center">
            <span className="text-white font-bold text-lg">Z</span>
          </div>
          <span className={`text-xl font-bold font-['League_Spartan'] ${isScrolled ? 'text-white' : 'text-white'}`}>
            Zahracak
          </span>
        </a>

        {/* Desktop Navigation */}
        <div className="hidden lg:flex items-center gap-8">
          {navItems.map((item) => (
            <a
              key={item.label}
              href={item.href}
              className="nav-link flex items-center gap-2 hover:text-[#FF5A36] transition-colors"
            >
              <item.icon className="w-4 h-4" />
              <span>{item.label}</span>
            </a>
          ))}
        </div>

        {/* Right Actions */}
        <div className="hidden lg:flex items-center gap-4">
          <button className="flex items-center gap-2 text-white/80 hover:text-white transition-colors">
            <ShoppingCart className="w-5 h-5" />
            <span className="text-sm">(0)</span>
          </button>
          <Link 
            to="/login" 
            className="flex items-center gap-2 text-white/80 hover:text-white transition-colors"
          >
            <User className="w-5 h-5" />
            <span className="text-sm">Sign In</span>
          </Link>
          <button className="btn-primary text-sm">Get the App</button>
        </div>

        {/* Mobile Menu Button */}
        <button
          className="lg:hidden text-white p-2"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden absolute top-full left-0 right-0 bg-[#2F4858]/98 backdrop-blur-md py-6 px-6">
          <div className="flex flex-col gap-4">
            {navItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                className="flex items-center gap-3 text-white/80 hover:text-white py-2"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                <item.icon className="w-5 h-5" />
                <span>{item.label}</span>
              </a>
            ))}
            <hr className="border-white/20 my-2" />
            <button className="flex items-center gap-3 text-white/80 hover:text-white py-2">
              <ShoppingCart className="w-5 h-5" />
              <span>Cart (0)</span>
            </button>
            <Link 
              to="/login" 
              className="flex items-center gap-3 text-white/80 hover:text-white py-2"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              <User className="w-5 h-5" />
              <span>Sign In</span>
            </Link>
            <button className="btn-primary mt-2">Get the App</button>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navigation;
