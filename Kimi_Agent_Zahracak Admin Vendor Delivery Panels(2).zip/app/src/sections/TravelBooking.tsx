import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface TravelBookingProps {
  className?: string;
}

const TravelBooking = ({ className = '' }: TravelBookingProps) => {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const bodyRef = useRef<HTMLParagraphElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLButtonElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0%-30%)
      // Headline from left
      scrollTl.fromTo(
        headlineRef.current,
        { x: '-50vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );

      // Body
      scrollTl.fromTo(
        bodyRef.current,
        { y: '10vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.1
      );

      // Right image from right
      scrollTl.fromTo(
        imageRef.current,
        { x: '55vw', scale: 0.92, opacity: 0 },
        { x: 0, scale: 1, opacity: 1, ease: 'none' },
        0.06
      );

      // CTA pops in
      scrollTl.fromTo(
        ctaRef.current,
        { scale: 0.9, opacity: 0 },
        { scale: 1, opacity: 1, ease: 'none' },
        0.18
      );

      // SETTLE (30%-70%): Hold

      // EXIT (70%-100%)
      scrollTl.to(
        [headlineRef.current, bodyRef.current],
        { y: '-10vh', opacity: 0.25, ease: 'power2.in' },
        0.7
      );

      scrollTl.to(
        imageRef.current,
        { y: '10vh', opacity: 0.35, ease: 'power2.in' },
        0.7
      );

      scrollTl.to(
        ctaRef.current,
        { opacity: 0.2, ease: 'power2.in' },
        0.8
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="travel"
      className={`section-coral section-pinned flex items-center ${className}`}
    >
      <div className="w-full h-full flex flex-col lg:flex-row items-center justify-between px-8 lg:px-[8vw] py-20">
        {/* Left Content */}
        <div className="flex-1 max-w-xl">
          {/* Headline */}
          <div ref={headlineRef}>
            <h2
              className="text-white font-['League_Spartan'] font-bold"
              style={{ fontSize: 'clamp(32px, 4.5vw, 56px)', lineHeight: 1.05 }}
            >
              Stays, flights
              <br />
              & buses.
            </h2>
          </div>

          {/* Body */}
          <p
            ref={bodyRef}
            className="mt-6 text-white/80 leading-relaxed"
            style={{ fontSize: 'clamp(15px, 1.3vw, 18px)' }}
          >
            Compare prices, book in seconds, and manage your trips—all inside Zahracak.
          </p>

          {/* CTA */}
          <button ref={ctaRef} className="btn-primary mt-10">
            Plan a Trip
          </button>
        </div>

        {/* Right Image */}
        <div
          ref={imageRef}
          className="flex-1 max-w-lg mt-10 lg:mt-0 lg:ml-12"
        >
          <div className="card-rounded overflow-hidden shadow-2xl">
            <img
              src="/travel_collage.jpg"
              alt="Travel booking - hotels, flights, buses"
              className="w-full h-auto object-cover"
              style={{ aspectRatio: '3/4' }}
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default TravelBooking;
