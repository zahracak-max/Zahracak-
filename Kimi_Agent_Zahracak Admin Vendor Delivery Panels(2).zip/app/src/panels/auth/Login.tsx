import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Eye, EyeOff, Mail, Lock, User, Store, Bike } from 'lucide-react';

interface LoginProps {
  defaultRole?: 'admin' | 'vendor' | 'delivery';
}

const Login = ({ defaultRole = 'admin' }: LoginProps) => {
  const navigate = useNavigate();
  const [role, setRole] = useState<'admin' | 'vendor' | 'delivery'>(defaultRole);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Simulate login
    setTimeout(() => {
      setIsLoading(false);
      switch (role) {
        case 'admin':
          navigate('/admin');
          break;
        case 'vendor':
          navigate('/vendor');
          break;
        case 'delivery':
          navigate('/delivery');
          break;
      }
    }, 1000);
  };

  const roleConfig = {
    admin: {
      icon: User,
      title: 'Admin Login',
      subtitle: 'Access the platform management dashboard',
      color: 'bg-[#FF5A36]',
    },
    vendor: {
      icon: Store,
      title: 'Vendor Login',
      subtitle: 'Manage your store and products',
      color: 'bg-blue-500',
    },
    delivery: {
      icon: Bike,
      title: 'Delivery Partner Login',
      subtitle: 'Track orders and manage deliveries',
      color: 'bg-green-500',
    },
  };

  const currentRole = roleConfig[role];
  const RoleIcon = currentRole.icon;

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Left Side - Branding */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-[#FF5A36] to-[#e54d2b] items-center justify-center p-12">
        <div className="text-white text-center">
          <div className="w-24 h-24 bg-white/20 rounded-3xl flex items-center justify-center mx-auto mb-8">
            <span className="text-5xl font-bold">Z</span>
          </div>
          <h1 className="text-4xl font-bold mb-4">Zahracak</h1>
          <p className="text-white/80 text-lg max-w-md">
            One app. Everything you need. Shop, ride, eat, travel, and more.
          </p>
          <div className="mt-12 flex justify-center gap-8">
            <div className="text-center">
              <p className="text-3xl font-bold">10K+</p>
              <p className="text-white/70 text-sm">Vendors</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold">50K+</p>
              <p className="text-white/70 text-sm">Users</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold">100K+</p>
              <p className="text-white/70 text-sm">Deliveries</p>
            </div>
          </div>
        </div>
      </div>

      {/* Right Side - Login Form */}
      <div className="flex-1 flex items-center justify-center p-6 lg:p-12">
        <div className="w-full max-w-md">
          {/* Role Selector */}
          <div className="flex gap-2 mb-8 p-1 bg-gray-100 rounded-xl">
            {(['admin', 'vendor', 'delivery'] as const).map((r) => (
              <button
                key={r}
                onClick={() => setRole(r)}
                className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium capitalize transition-all ${
                  role === r
                    ? 'bg-white text-[#2F4858] shadow-sm'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                {r}
              </button>
            ))}
          </div>

          {/* Header */}
          <div className="text-center mb-8">
            <div className={`w-16 h-16 ${currentRole.color} rounded-2xl flex items-center justify-center mx-auto mb-4`}>
              <RoleIcon className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-[#2F4858]">{currentRole.title}</h2>
            <p className="text-gray-500 mt-1">{currentRole.subtitle}</p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Email Address
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FF5A36] focus:border-transparent"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Password
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  className="w-full pl-10 pr-12 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FF5A36] focus:border-transparent"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" className="w-4 h-4 rounded border-gray-300 text-[#FF5A36] focus:ring-[#FF5A36]" />
                <span className="text-sm text-gray-600">Remember me</span>
              </label>
              <a href="#" className="text-sm text-[#FF5A36] hover:underline">
                Forgot password?
              </a>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-[#FF5A36] text-white py-3 rounded-xl font-medium hover:bg-[#e54d2b] transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
              ) : (
                'Sign In'
              )}
            </button>
          </form>

          {/* Demo Credentials */}
          <div className="mt-8 p-4 bg-gray-50 rounded-xl">
            <p className="text-sm text-gray-500 mb-2">Demo Credentials:</p>
            <div className="space-y-1 text-sm">
              <p className="text-gray-600">
                <span className="font-medium">Admin:</span> admin@zahracak.com / admin123
              </p>
              <p className="text-gray-600">
                <span className="font-medium">Vendor:</span> vendor@zahracak.com / vendor123
              </p>
              <p className="text-gray-600">
                <span className="font-medium">Delivery:</span> delivery@zahracak.com / delivery123
              </p>
            </div>
          </div>

          {/* Back to Home */}
          <div className="mt-6 text-center">
            <a href="/" className="text-sm text-gray-500 hover:text-[#FF5A36] transition-colors">
              ← Back to homepage
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
