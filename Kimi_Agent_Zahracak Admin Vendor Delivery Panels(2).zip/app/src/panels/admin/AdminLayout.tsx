import { Outlet } from 'react-router-dom';
import Sidebar from '../components/Sidebar';
import {
  LayoutDashboard,
  Users,
  Store,
  ShoppingBag,
  Truck,
  CreditCard,
  Settings,
  BarChart3,
  MessageSquare,
  Flag,
} from 'lucide-react';

const adminMenuItems = [
  { icon: LayoutDashboard, label: 'Dashboard', path: '/admin' },
  { icon: Users, label: 'Users', path: '/admin/users', badge: 12 },
  { icon: Store, label: 'Vendors', path: '/admin/vendors', badge: 5 },
  { icon: ShoppingBag, label: 'Orders', path: '/admin/orders', badge: 28 },
  { icon: Truck, label: 'Delivery', path: '/admin/delivery' },
  { icon: CreditCard, label: 'Payments', path: '/admin/payments' },
  { icon: BarChart3, label: 'Analytics', path: '/admin/analytics' },
  { icon: MessageSquare, label: 'Support', path: '/admin/support', badge: 8 },
  { icon: Flag, label: 'Reports', path: '/admin/reports' },
  { icon: Settings, label: 'Settings', path: '/admin/settings' },
];

const adminUser = {
  name: 'Admin User',
  role: 'Super Admin',
  avatar: 'A',
};

const AdminLayout = () => {
  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar items={adminMenuItems} user={adminUser} logoText="Admin Panel" />
      <main className="flex-1 lg:ml-0">
        <Outlet />
      </main>
    </div>
  );
};

export default AdminLayout;
