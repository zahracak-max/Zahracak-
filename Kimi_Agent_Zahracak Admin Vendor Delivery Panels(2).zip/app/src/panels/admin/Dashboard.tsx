import { useState } from 'react';
import {
  Users,
  Store,
  ShoppingBag,
  DollarSign,
  Bell,
  Search,
  CheckCircle,
  XCircle,
  Clock,
} from 'lucide-react';
import StatCard from '../components/StatCard';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';

const revenueData = [
  { name: 'Jan', revenue: 45000, orders: 320 },
  { name: 'Feb', revenue: 52000, orders: 380 },
  { name: 'Mar', revenue: 48000, orders: 350 },
  { name: 'Apr', revenue: 61000, orders: 420 },
  { name: 'May', revenue: 58000, orders: 400 },
  { name: 'Jun', revenue: 72000, orders: 510 },
  { name: 'Jul', revenue: 68000, orders: 480 },
];

const categoryData = [
  { name: 'Electronics', value: 35, color: '#FF5A36' },
  { name: 'Fashion', value: 25, color: '#2F4858' },
  { name: 'Food', value: 20, color: '#10B981' },
  { name: 'Home', value: 15, color: '#8B5CF6' },
  { name: 'Others', value: 5, color: '#6B7280' },
];

const recentOrders = [
  { id: '#ORD-001', customer: 'John Doe', vendor: 'Urban Electronics', amount: 299.99, status: 'completed', date: '2024-03-13' },
  { id: '#ORD-002', customer: 'Jane Smith', vendor: 'Fresh Mart', amount: 45.50, status: 'processing', date: '2024-03-13' },
  { id: '#ORD-003', customer: 'Mike Johnson', vendor: 'Style Studio', amount: 129.00, status: 'pending', date: '2024-03-12' },
  { id: '#ORD-004', customer: 'Sarah Williams', vendor: 'Home Comfort', amount: 89.99, status: 'completed', date: '2024-03-12' },
  { id: '#ORD-005', customer: 'David Brown', vendor: 'Urban Electronics', amount: 599.00, status: 'cancelled', date: '2024-03-11' },
];

const pendingVendors = [
  { id: 1, name: 'Tech World Store', email: 'tech@example.com', category: 'Electronics', applied: '2 days ago' },
  { id: 2, name: 'Fashion Hub', email: 'fashion@example.com', category: 'Fashion', applied: '3 days ago' },
  { id: 3, name: 'Organic Foods', email: 'organic@example.com', category: 'Groceries', applied: '1 day ago' },
];

const getStatusColor = (status: string) => {
  switch (status) {
    case 'completed':
      return 'bg-green-100 text-green-700';
    case 'processing':
      return 'bg-blue-100 text-blue-700';
    case 'pending':
      return 'bg-yellow-100 text-yellow-700';
    case 'cancelled':
      return 'bg-red-100 text-red-700';
    default:
      return 'bg-gray-100 text-gray-700';
  }
};

const getStatusIcon = (status: string) => {
  switch (status) {
    case 'completed':
      return <CheckCircle className="w-4 h-4" />;
    case 'processing':
      return <Clock className="w-4 h-4" />;
    case 'pending':
      return <Clock className="w-4 h-4" />;
    case 'cancelled':
      return <XCircle className="w-4 h-4" />;
    default:
      return null;
  }
};

const AdminDashboard = () => {
  const [dateRange, setDateRange] = useState('7d');

  return (
    <div className="p-6 lg:p-8">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl font-bold text-[#2F4858]">Dashboard</h1>
          <p className="text-gray-500">Welcome back! Here's what's happening today.</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search..."
              className="pl-10 pr-4 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#FF5A36] w-64"
            />
          </div>
          <button className="relative p-2 border border-gray-200 rounded-xl hover:bg-gray-50">
            <Bell className="w-5 h-5 text-gray-600" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-[#FF5A36] rounded-full"></span>
          </button>
          <select
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
            className="px-4 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#FF5A36]"
          >
            <option value="24h">Last 24 hours</option>
            <option value="7d">Last 7 days</option>
            <option value="30d">Last 30 days</option>
            <option value="90d">Last 90 days</option>
          </select>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard
          title="Total Revenue"
          value="$68,420"
          change={12.5}
          icon={DollarSign}
          color="green"
        />
        <StatCard
          title="Total Orders"
          value="1,284"
          change={8.2}
          icon={ShoppingBag}
          color="orange"
        />
        <StatCard
          title="Active Users"
          value="8,549"
          change={15.3}
          icon={Users}
          color="blue"
        />
        <StatCard
          title="Active Vendors"
          value="342"
          change={5.7}
          icon={Store}
          color="purple"
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Revenue Chart */}
        <div className="lg:col-span-2 bg-white rounded-2xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-bold text-[#2F4858]">Revenue & Orders</h3>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-[#FF5A36] rounded-full"></div>
                <span className="text-sm text-gray-500">Revenue</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-[#2F4858] rounded-full"></div>
                <span className="text-sm text-gray-500">Orders</span>
              </div>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={revenueData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="name" stroke="#9CA3AF" fontSize={12} />
              <YAxis yAxisId="left" stroke="#9CA3AF" fontSize={12} />
              <YAxis yAxisId="right" orientation="right" stroke="#9CA3AF" fontSize={12} />
              <Tooltip />
              <Line
                yAxisId="left"
                type="monotone"
                dataKey="revenue"
                stroke="#FF5A36"
                strokeWidth={2}
                dot={{ fill: '#FF5A36', strokeWidth: 2 }}
              />
              <Line
                yAxisId="right"
                type="monotone"
                dataKey="orders"
                stroke="#2F4858"
                strokeWidth={2}
                dot={{ fill: '#2F4858', strokeWidth: 2 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Category Distribution */}
        <div className="bg-white rounded-2xl p-6 shadow-sm">
          <h3 className="font-bold text-[#2F4858] mb-6">Sales by Category</h3>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie
                data={categoryData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={90}
                dataKey="value"
              >
                {categoryData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          <div className="mt-4 space-y-2">
            {categoryData.map((item) => (
              <div key={item.name} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: item.color }}
                  ></div>
                  <span className="text-sm text-gray-600">{item.name}</span>
                </div>
                <span className="text-sm font-medium text-[#2F4858]">{item.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Orders */}
        <div className="bg-white rounded-2xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-bold text-[#2F4858]">Recent Orders</h3>
            <button className="text-[#FF5A36] text-sm font-medium hover:underline">
              View All
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-100">
                  <th className="text-left py-3 text-xs font-medium text-gray-500 uppercase">Order ID</th>
                  <th className="text-left py-3 text-xs font-medium text-gray-500 uppercase">Customer</th>
                  <th className="text-left py-3 text-xs font-medium text-gray-500 uppercase">Amount</th>
                  <th className="text-left py-3 text-xs font-medium text-gray-500 uppercase">Status</th>
                </tr>
              </thead>
              <tbody>
                {recentOrders.map((order) => (
                  <tr key={order.id} className="border-b border-gray-50 last:border-0">
                    <td className="py-3 text-sm font-medium text-[#2F4858]">{order.id}</td>
                    <td className="py-3 text-sm text-gray-600">{order.customer}</td>
                    <td className="py-3 text-sm font-medium text-[#2F4858]">${order.amount}</td>
                    <td className="py-3">
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(
                          order.status
                        )}`}
                      >
                        {getStatusIcon(order.status)}
                        {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Pending Vendor Approvals */}
        <div className="bg-white rounded-2xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-bold text-[#2F4858]">Pending Vendor Approvals</h3>
            <button className="text-[#FF5A36] text-sm font-medium hover:underline">
              View All
            </button>
          </div>
          <div className="space-y-4">
            {pendingVendors.map((vendor) => (
              <div
                key={vendor.id}
                className="flex items-center justify-between p-4 border border-gray-100 rounded-xl hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-[#FF5A36]/10 rounded-xl flex items-center justify-center">
                    <Store className="w-6 h-6 text-[#FF5A36]" />
                  </div>
                  <div>
                    <p className="font-medium text-[#2F4858]">{vendor.name}</p>
                    <p className="text-sm text-gray-500">{vendor.email}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full">
                        {vendor.category}
                      </span>
                      <span className="text-xs text-gray-400">{vendor.applied}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button className="p-2 text-green-500 hover:bg-green-50 rounded-lg transition-colors">
                    <CheckCircle className="w-5 h-5" />
                  </button>
                  <button className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors">
                    <XCircle className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
