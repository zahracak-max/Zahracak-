import { Outlet } from 'react-router-dom';
import Sidebar from '../components/Sidebar';
import {
  LayoutDashboard,
  Package,
  MapPin,
  Wallet,
  Settings,
  History,
  TrendingUp,
  MessageSquare,
} from 'lucide-react';

const deliveryMenuItems = [
  { icon: LayoutDashboard, label: 'Dashboard', path: '/delivery' },
  { icon: Package, label: 'Active Orders', path: '/delivery/orders', badge: 3 },
  { icon: MapPin, label: 'My Route', path: '/delivery/route' },
  { icon: History, label: 'History', path: '/delivery/history' },
  { icon: Wallet, label: 'Earnings', path: '/delivery/earnings' },
  { icon: TrendingUp, label: 'Performance', path: '/delivery/performance' },
  { icon: MessageSquare, label: 'Support', path: '/delivery/support' },
  { icon: Settings, label: 'Settings', path: '/delivery/settings' },
];

const deliveryUser = {
  name: 'Ahmed Hassan',
  role: 'Delivery Partner',
  avatar: 'A',
};

const DeliveryLayout = () => {
  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar items={deliveryMenuItems} user={deliveryUser} logoText="Delivery Panel" />
      <main className="flex-1 lg:ml-0">
        <Outlet />
      </main>
    </div>
  );
};

export default DeliveryLayout;
