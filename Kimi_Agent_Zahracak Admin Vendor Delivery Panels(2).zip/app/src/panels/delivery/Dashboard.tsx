import { useState } from 'react';
import {
  DollarSign,
  Package,
  Clock,
  MapPin,
  Star,
  Phone,
  Navigation,
  Bell,
} from 'lucide-react';
import StatCard from '../components/StatCard';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';

const earningsData = [
  { name: 'Mon', earnings: 85 },
  { name: 'Tue', earnings: 120 },
  { name: 'Wed', earnings: 95 },
  { name: 'Thu', earnings: 140 },
  { name: 'Fri', earnings: 165 },
  { name: 'Sat', earnings: 200 },
  { name: 'Sun', earnings: 180 },
];

const activeOrders = [
  {
    id: '#DEL-001',
    customer: 'John Doe',
    phone: '+1 234 567 890',
    address: '123 Main St, Apt 4B',
    items: 3,
    amount: 45.50,
    status: 'pickup',
    eta: '5 min',
    vendor: 'Fresh Mart',
    vendorAddress: '456 Market St',
  },
  {
    id: '#DEL-002',
    customer: 'Jane Smith',
    phone: '+1 234 567 891',
    address: '789 Oak Ave, Suite 12',
    items: 1,
    amount: 29.99,
    status: 'delivering',
    eta: '12 min',
    vendor: 'Urban Electronics',
    vendorAddress: '321 Tech Blvd',
  },
  {
    id: '#DEL-003',
    customer: 'Mike Johnson',
    phone: '+1 234 567 892',
    address: '555 Pine Rd, House 7',
    items: 5,
    amount: 78.25,
    status: 'pickup',
    eta: '8 min',
    vendor: 'Style Studio',
    vendorAddress: '888 Fashion Ave',
  },
];

const todayStats = {
  completed: 12,
  earnings: 185.50,
  hours: 6.5,
  rating: 4.9,
};

const getStatusColor = (status: string) => {
  switch (status) {
    case 'pickup':
      return 'bg-orange-100 text-orange-700';
    case 'delivering':
      return 'bg-blue-100 text-blue-700';
    case 'completed':
      return 'bg-green-100 text-green-700';
    default:
      return 'bg-gray-100 text-gray-700';
  }
};

const getStatusText = (status: string) => {
  switch (status) {
    case 'pickup':
      return 'Pickup';
    case 'delivering':
      return 'Delivering';
    case 'completed':
      return 'Completed';
    default:
      return status;
  }
};

const DeliveryDashboard = () => {
  const [isOnline, setIsOnline] = useState(true);

  return (
    <div className="p-6 lg:p-8">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl font-bold text-[#2F4858]">Delivery Dashboard</h1>
          <p className="text-gray-500">Manage your deliveries and earnings.</p>
        </div>
        <div className="flex items-center gap-3">
          {/* Online/Offline Toggle */}
          <button
            onClick={() => setIsOnline(!isOnline)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl font-medium transition-all ${
              isOnline
                ? 'bg-green-500 text-white'
                : 'bg-gray-200 text-gray-600'
            }`}
          >
            <div className={`w-2 h-2 rounded-full ${isOnline ? 'bg-white animate-pulse' : 'bg-gray-500'}`}></div>
            {isOnline ? 'Online' : 'Offline'}
          </button>
          <button className="relative p-2 border border-gray-200 rounded-xl hover:bg-gray-50">
            <Bell className="w-5 h-5 text-gray-600" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-[#FF5A36] rounded-full"></span>
          </button>
        </div>
      </div>

      {/* Today's Stats */}
      <div className="bg-gradient-to-r from-[#FF5A36] to-[#e54d2b] rounded-2xl p-6 text-white mb-8">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold text-lg">Today's Performance</h3>
          <span className="text-white/80 text-sm">{new Date().toLocaleDateString()}</span>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          <div>
            <p className="text-white/70 text-sm mb-1">Deliveries</p>
            <p className="text-3xl font-bold">{todayStats.completed}</p>
          </div>
          <div>
            <p className="text-white/70 text-sm mb-1">Earnings</p>
            <p className="text-3xl font-bold">${todayStats.earnings}</p>
          </div>
          <div>
            <p className="text-white/70 text-sm mb-1">Hours Online</p>
            <p className="text-3xl font-bold">{todayStats.hours}h</p>
          </div>
          <div>
            <p className="text-white/70 text-sm mb-1">Rating</p>
            <div className="flex items-center gap-1">
              <p className="text-3xl font-bold">{todayStats.rating}</p>
              <Star className="w-5 h-5 fill-white" />
            </div>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard
          title="Weekly Earnings"
          value="$985"
          change={15.3}
          icon={DollarSign}
          color="green"
        />
        <StatCard
          title="Total Deliveries"
          value="156"
          change={8.2}
          icon={Package}
          color="orange"
        />
        <StatCard
          title="Avg. Delivery Time"
          value="18 min"
          change={-5.2}
          icon={Clock}
          color="blue"
        />
        <StatCard
          title="Customer Rating"
          value="4.9"
          change={2.1}
          icon={Star}
          color="purple"
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Active Orders */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-2xl p-6 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-bold text-[#2F4858]">Active Orders ({activeOrders.length})</h3>
              <button className="text-[#FF5A36] text-sm font-medium hover:underline">
                View All
              </button>
            </div>
            <div className="space-y-4">
              {activeOrders.map((order) => (
                <div
                  key={order.id}
                  className="border border-gray-100 rounded-xl p-4 hover:shadow-md transition-shadow"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-bold text-[#2F4858]">{order.id}</span>
                        <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
                          {getStatusText(order.status)}
                        </span>
                      </div>
                      <p className="text-sm text-gray-500">{order.items} items • ${order.amount}</p>
                    </div>
                    <span className="text-sm text-[#FF5A36] font-medium">{order.eta}</span>
                  </div>

                  <div className="space-y-3">
                    {/* Pickup Location */}
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <Package className="w-4 h-4 text-orange-500" />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium text-[#2F4858]">{order.vendor}</p>
                        <p className="text-sm text-gray-500">{order.vendorAddress}</p>
                      </div>
                    </div>

                    {/* Delivery Location */}
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <MapPin className="w-4 h-4 text-green-500" />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium text-[#2F4858]">{order.customer}</p>
                        <p className="text-sm text-gray-500">{order.address}</p>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-3 mt-4 pt-4 border-t border-gray-100">
                    <a
                      href={`tel:${order.phone}`}
                      className="flex items-center gap-2 px-4 py-2 border border-gray-200 rounded-lg text-sm font-medium hover:bg-gray-50 transition-colors"
                    >
                      <Phone className="w-4 h-4" />
                      Call
                    </a>
                    <button className="flex items-center gap-2 px-4 py-2 border border-gray-200 rounded-lg text-sm font-medium hover:bg-gray-50 transition-colors">
                      <Navigation className="w-4 h-4" />
                      Navigate
                    </button>
                    <button className="flex-1 bg-[#FF5A36] text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-[#e54d2b] transition-colors">
                      {order.status === 'pickup' ? 'Mark Picked Up' : 'Mark Delivered'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Earnings Chart */}
          <div className="bg-white rounded-2xl p-6 shadow-sm">
            <h3 className="font-bold text-[#2F4858] mb-4">Weekly Earnings</h3>
            <ResponsiveContainer width="100%" height={180}>
              <LineChart data={earningsData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="name" stroke="#9CA3AF" fontSize={10} />
                <YAxis stroke="#9CA3AF" fontSize={10} />
                <Tooltip />
                <Line
                  type="monotone"
                  dataKey="earnings"
                  stroke="#FF5A36"
                  strokeWidth={2}
                  dot={{ fill: '#FF5A36', strokeWidth: 2 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Quick Stats */}
          <div className="bg-white rounded-2xl p-6 shadow-sm">
            <h3 className="font-bold text-[#2F4858] mb-4">This Month</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                    <DollarSign className="w-5 h-5 text-green-500" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Total Earnings</p>
                    <p className="font-bold text-[#2F4858]">$3,450</p>
                  </div>
                </div>
                <span className="text-green-500 text-sm font-medium">+12%</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                    <Package className="w-5 h-5 text-blue-500" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Deliveries</p>
                    <p className="font-bold text-[#2F4858]">542</p>
                  </div>
                </div>
                <span className="text-green-500 text-sm font-medium">+8%</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                    <Clock className="w-5 h-5 text-purple-500" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Hours Online</p>
                    <p className="font-bold text-[#2F4858]">168h</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Incentives */}
          <div className="bg-gradient-to-br from-[#2F4858] to-[#3d5a6d] rounded-2xl p-6 text-white">
            <h3 className="font-bold mb-2">Daily Challenge</h3>
            <p className="text-white/70 text-sm mb-4">
              Complete 5 more deliveries to earn a $20 bonus!
            </p>
            <div className="w-full bg-white/20 rounded-full h-2 mb-4">
              <div className="bg-[#FF5A36] h-2 rounded-full" style={{ width: '70%' }}></div>
            </div>
            <p className="text-sm text-white/70">7/12 deliveries completed</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DeliveryDashboard;
